import { SearchResult } from '../../../shared/search/models/search-result.model';
import { AdminNotifyMessage } from './admin-notify-message.model';

export class AdminNotifySearchResult extends SearchResult<AdminNotifyMessage> {
}
