
export const QUALITY_ASSURANCE_EDIT_PATH = 'quality-assurance';
export const PUBLICATION_CLAIMS_PATH = 'publication-claim';

export function getQualityAssuranceEditRoute() {
  return `/${QUALITY_ASSURANCE_EDIT_PATH}`;
}
