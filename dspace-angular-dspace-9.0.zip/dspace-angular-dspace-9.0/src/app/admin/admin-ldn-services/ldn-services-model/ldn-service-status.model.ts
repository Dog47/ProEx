/**
 * List of services statuses
 */
export enum LdnServiceStatus {
  UNKNOWN,
  DISABLED,
  ENABLED,
}
